function Para=Para_SEIRDC(beta1, beta2, beta3, beta4, delta1,delta2,delta3)


M=6; q=[3,5]; L=length(q);

A_d=zeros(M);  A_d(2,3)=delta1;A_d(3,4)=delta2;A_d(3,5)=delta3;
A_b=zeros(M,M,L); A_b(1,2,1)=beta1; A_b(1,6,2)=beta2; A_b(2,6,2)=beta3; A_b(3,6,2)=beta4; 


Para={M,q,L,A_d,A_b};