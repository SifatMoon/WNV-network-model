function gemfMain= GEMFMain()
    % Faryad Darabi Sahneh
% Kansas State University
% Last Modified: Sep 2013
% Copyright (c) 2013, Faryad Darabi Sahneh. All rights reserved. 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted




clear; clc

%Network generation
N=300;
LocalNet= localNet();
LinkAnSub= netForExpKer();
finalNet= [LocalNet; LinkAnSub];
% r=sqrt(5*log(N)/N);
% Net1=NetGen_Geo2(N,r);
% p=2*log(N)/N;
% Net2=NetGen_ER2(N,p);
% Net=NetCmbn2({Net1,Net2});

% Parameters and initial conditions for the model 
 lambda1=10;
delta=1; beta=5/lambda1; beta_a=0.5/lambda1; kappa=1*beta; mu=1*beta;
 Para=Para_SAIS(delta,beta,beta_a,kappa,mu); M=Para{1};
 x0=Initial_Cond_Gen(N,'Population',[2],[20]);

 

  tic;
StopCond={'RunTime',100};
[ts,n_index,i_index,j_index]=GEMF_SIM2(Para,Net,x0,StopCond);
toc;

% Post Processing
  StatesPlot=[1,2,3];
[T, StateCount]=Post_Population(x0,M,N,ts,i_index,j_index);
plot(T,StateCount(StatesPlot,:)/N); 
for lg=1:length(StatesPlot)
    legendsymb{lg}=int2str(StatesPlot(lg));
end;
legend(legendsymb);
  
  
  