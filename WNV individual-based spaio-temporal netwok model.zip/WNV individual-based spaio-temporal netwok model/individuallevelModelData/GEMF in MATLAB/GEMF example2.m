% Faryad Darabi Sahneh
% Kansas State University
% Last Modified: Sep 2013
% Copyright (c) 2013, Faryad Darabi Sahneh. All rights reserved. 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted


clear; clc

% Initial Setup

N=379;  %Number of nodes
File='edgesweight.txt';   Net=Net_Import3(File,N,'directed');
% directed: if the network is 'directed', in the text file, first element in each row is the start of edge, second element is end of edge, third element is weight of edge 
% undirected: if the network is 'undirected', there is no need to repeat
% the row (i,j,w) as (j,i,w) in the text file. it is enough that the file only include the row (i,j,w)



% Parameters and initial conditions for the model 

lambda1=10;
delta=1; beta=3/lambda1;
Para=Para_SIS(delta,beta); M=Para{1};


x0=ones(1,N); x0(1:10)=2; %initial condition of the network, "1" represents susceptible "2" represents infected

%x0=Initial_Cond_Gen(N,'Population',[2],[10]); %initial condition can be generated using Initial_Cond_Gen function



tic;
StopCond={'RunTime',100};
[ts,n_index,i_index,j_index]=GEMF_SIM2(Para,Net,x0,StopCond);
toc;

% Post Processing
StatesPlot=[1,2];
[T, StateCount]=Post_Population(x0,M,N,ts,i_index,j_index);
plot(T,StateCount(StatesPlot,:)/N); 
for lg=1:length(StatesPlot)
    legendsymb{lg}=strcat('Compartment',int2str(StatesPlot(lg)));
end;
legend(legendsymb);




X0=zeros(M,N);
for i=1:N
    X0(x0(i),i)=1;
end;
tic;
[t,X]=GEMF_ODE2(Para,Net,X0,T(end));
toc;
hold on;
% plot(t,sum(X(:,2:3:end),2)/N,'r')
% plot(t,sum(X(:,3:3:end),2)/N,'b')
for k=1:length(StatesPlot)
    plot(t,sum(X(:,StatesPlot(k):M:end),2)/N,'k','linewidth',2);
end;







%________Another Example__________________

clear; clc

%Network generation
N=300;
r=sqrt(5*log(N)/N);
Net1=NetGen_Geo2(N,r);
p=2*log(N)/N;
Net2=NetGen_ER2(N,p);
Net=NetCmbn2({Net1,Net2});

% Parameters and initial conditions for the model 
 lambda1=10;
delta=1; beta=5/lambda1; beta_a=0.5/lambda1; kappa=1*beta; mu=1*beta;
 Para=Para_SAIS(delta,beta,beta_a,kappa,mu); M=Para{1};
 x0=Initial_Cond_Gen(N,'Population',[2],[20]);

 

  tic;
StopCond={'RunTime',100};
[ts,n_index,i_index,j_index]=GEMF_SIM2(Para,Net,x0,StopCond);
toc;

% Post Processing
  StatesPlot=[1,2,3];
[T, StateCount]=Post_Population(x0,M,N,ts,i_index,j_index);
plot(T,StateCount(StatesPlot,:)/N); 
for lg=1:length(StatesPlot)
    legendsymb{lg}=int2str(StatesPlot(lg));
end;
legend(legendsymb);
  
  
  