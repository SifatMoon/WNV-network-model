function Para=Para_SAIS(delta,beta,beta_a,kappa,mu)


M=3; q=[2]; L=length(q);

A_d=zeros(M); A_d(2,1)=delta;
A_b=zeros(M,M,L); A_b(1,2,1)=beta; A_b(1,3,1)=kappa; A_b(3,2,1)=beta_a; A_b(1,3,2)=mu;


Para={M,q,L,A_d,A_b};